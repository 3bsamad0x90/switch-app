<!-- form -->
<div class="row">
    <div class="col-12 col-md-6">
        <label class="form-label" for="phone"><?php echo e(trans('common.phone')); ?></label>
        <?php echo e(Form::text('phone',getSettingValue('phone'),['id'=>'phone','class'=>'form-control'])); ?>

    </div>

    <div class="col-12 col-md-6">
        <label class="form-label" for="email"><?php echo e(trans('common.email')); ?></label>
        <?php echo e(Form::text('email',getSettingValue('email'),['id'=>'email','class'=>'form-control'])); ?>

    </div>

</div>
<!--/ form -->
<?php /**PATH C:\xampp\htdocs\Laravel\switch-app\resources\views/AdminPanel/settings/includes/contact.blade.php ENDPATH**/ ?>