<?php $__env->startSection('content'); ?>


    <!-- Bordered table start -->
    <div class="row" id="table-bordered">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title"><?php echo e($title); ?></h4>
                </div>
                <div class="table-responsive">
                    <table class="table table-bordered mb-2">
                        <thead>
                            <tr>
                                <th>الموضوع</th>
                                <th>الحالة</th>
                                <th class="text-center">الإجراءات</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr id="row_<?php echo e($message->id); ?>">
                                <td>
                                    <a href="<?php echo e(route('admin.contactmessages.details',['id'=>$message->id])); ?>">
                                        <b><?php echo e($message->userData()['name']); ?></b>
                                        | <?php echo e($message->fromTime()); ?>

                                    </a>
                                </td>
                                <td><?php echo $message->messageStatus(); ?></td>
                                <td class="text-center">
                                    <?php $delete = route('admin.contactmessages.delete',['id'=>$message->id]); ?>
                                    <button type="button" class="btn btn-icon btn-danger" onclick="confirmDelete('<?php echo e($delete); ?>','<?php echo e($message->id); ?>')" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-original-title="<?php echo e(trans('common.delete')); ?>">
                                        <i data-feather='trash-2'></i>
                                    </button>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="5" class="p-3 text-center ">
                                        <h2>لا يوجد أي بيانات لعرضها الآن</h2>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                    <?php echo e($messages->links('vendor.pagination.default')); ?>

                </div>


            </div>
        </div>
    </div>
    <!-- Bordered table end -->



<?php $__env->stopSection(); ?>

<?php echo $__env->make('AdminPanel.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\switch-app\resources\views/AdminPanel/contactMessages/index.blade.php ENDPATH**/ ?>