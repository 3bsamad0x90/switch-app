<?php
    $countUnreadMessage = App\ContactMessages::where('user_type',null)->where('status','0')->count();
    $UnreadMessage = App\ContactMessages::where('user_type',null)->where('status','0')->take(15)->get();
    if ($countUnreadMessage > 99) {
        $countUnreadMessage = '+99';
    }
?>
<li class="nav-item dropdown dropdown-notification me-25">
    <a class="nav-link" href="#" data-bs-toggle="dropdown">
        <i class="ficon" data-feather="mail"></i>
        <?php if($countUnreadMessage != 0): ?>
            <span class="badge rounded-pill bg-success badge-up"><?php echo e($countUnreadMessage); ?></span>
        <?php endif; ?>
    </a>
    <ul class="dropdown-menu dropdown-menu-media dropdown-menu-end">
        <li class="dropdown-menu-header">
            <div class="dropdown-header d-flex">
                <h4 class="notification-title mb-0 me-auto"><?php echo e(trans('common.contactMessages')); ?></h4>
                <?php if($countUnreadMessage != 0): ?>
                    <div class="badge rounded-pill badge-light-primary"><?php echo e($countUnreadMessage); ?> <?php echo e(trans('common.unread')); ?></div>
                <?php endif; ?>
            </div>
        </li>
        <li class="scrollable-container media-list">
            <?php $__empty_1 = true; $__currentLoopData = $UnreadMessage; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $UnreadMessag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <a class="d-flex" href="<?php echo e(route('admin.contactmessages.details',['id'=>$UnreadMessag->id])); ?>">
                    <div class="list-item d-flex align-items-start">
                        <div class="list-item-body flex-grow-1">
                            <p class="media-heading">
                                <span class="fw-bolder"><?php echo e(trans('common.YouGotMessageFrom')); ?></span>
                                <?php echo e($UnreadMessag->name); ?>

                            </p>
                            <small class="notification-text"><?php echo e($UnreadMessag->supject); ?></small><br>
                            <small class="notification-text"><?php echo e($UnreadMessag->fromTime()); ?></small>
                        </div>
                    </div>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

            <?php endif; ?>
        </li>
        <li class="dropdown-menu-footer"><a class="btn btn-primary w-100" href="#">Read all notifications</a></li>
    </ul>
</li>
<?php /**PATH C:\xampp\htdocs\Laravel\switch-app\resources\views/AdminPanel/layouts/topbar/contactMessages.blade.php ENDPATH**/ ?>