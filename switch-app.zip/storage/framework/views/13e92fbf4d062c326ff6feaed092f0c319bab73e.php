<!-- form -->
<div class="row">
    <div class="divider">
        <div class="divider-text"><?php echo e(trans('common.siteMainSEO')); ?></div>
    </div>
    <div class="col-12 col-md-6">
        <label class="form-label" for="siteTitle_ar"><?php echo e(trans('common.siteTitle_ar')); ?></label>
        <?php echo e(Form::text('siteTitle_ar',getSettingValue('siteTitle_ar'),['id'=>'siteTitle_ar','class'=>'form-control'])); ?>

    </div>
    <div class="col-12 col-md-6">
        <label class="form-label" for="siteTitle_en"><?php echo e(trans('common.siteTitle_en')); ?></label>
        <?php echo e(Form::text('siteTitle_en',getSettingValue('siteTitle_en'),['id'=>'siteTitle_en','class'=>'form-control'])); ?>

    </div>
    <div class="col-12 col-md-12">
        <label class="form-label" for="siteDescription"><?php echo e(trans('common.siteDescription')); ?></label>
        <?php echo e(Form::textarea('siteDescription',getSettingValue('siteDescription'),['rows'=>'3','id'=>'siteDescription','class'=>'form-control'])); ?>

    </div>
 

</div>
<!--/ form -->
<?php /**PATH C:\xampp\htdocs\Laravel\switch-app\resources\views/AdminPanel/settings/includes/general.blade.php ENDPATH**/ ?>