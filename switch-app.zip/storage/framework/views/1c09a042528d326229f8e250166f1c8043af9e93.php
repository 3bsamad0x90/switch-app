
<?php $__env->startSection('content'); ?>


    <!-- Bordered table start -->
    <div class="row" id="table-bordered">
        <div class="col-12">
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
            <?php echo e(Form::open(['url'=>route('admin.apps.update'), 'files'=>'true'])); ?>

            <div class="card">
                <div class="card-body">
                    <ul class="nav nav-tabs" role="tablist">
                        <li class="nav-item">
                            <a class="nav-link active" id="social-tab" data-bs-toggle="tab" href="#social" aria-controls="home" role="tab" aria-selected="true">
                                <i data-feather="aperture"></i>  تطبيقات السوشيال ميديا
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" id="music-tab" data-bs-toggle="tab" href="#music" aria-controls="music" role="tab" aria-selected="false">
                                <i data-feather="headphones"></i> تطبيقات الأغاني
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" id="business-tab" data-bs-toggle="tab" href="#business" aria-controls="business" role="tab" aria-selected="false">
                                <i data-feather="briefcase"></i> تطبيقات تجارية
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" id="creative-tab" data-bs-toggle="tab" href="#creative" aria-controls="creative" role="tab" aria-selected="false">
                                <i data-feather="book-open"></i>تطبيقات كرييتف
                            </a>
                        </li>

                    </ul>
                    <div class="tab-content">
                        <div class="tab-pane active" id="social" aria-labelledby="social-tab" role="tabpanel">
                            <?php echo $__env->make('AdminPanel.apps.includes.social', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                        <div class="tab-pane" id="music" aria-labelledby="music-tab" role="tabpanel">
                            <?php echo $__env->make('AdminPanel.apps.includes.music', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                        <div class="tab-pane" id="business" aria-labelledby="business-tab" role="tabpanel">
                            <?php echo $__env->make('AdminPanel.apps.includes.business', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                        <div class="tab-pane" id="creative" aria-labelledby="creative-tab" role="tabpanel">
                            <?php echo $__env->make('AdminPanel.apps.includes.creative', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>

                    </div>
                </div>
                <div class="card-footer">
                    <input type="submit" value="<?php echo e(trans('common.Save changes')); ?>" class="btn btn-primary">
                </div>
            </div>
            <?php echo e(Form::close()); ?>

        </div>
    </div>
    <!-- Bordered table end -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('AdminPanel.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\switch-app\resources\views/AdminPanel/apps/index.blade.php ENDPATH**/ ?>