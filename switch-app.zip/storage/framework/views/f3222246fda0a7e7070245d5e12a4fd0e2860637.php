<?php $__env->startSection('content'); ?>


    <!-- Bordered table start -->
    <div class="row" id="table-bordered">
        <div class="col-12">
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul class="text-bold">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="mb-1 text-bold"><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title"><?php echo e($title); ?></h4>
                </div>
                <div class="table-responsive">
                    <table class="table table-bordered mb-2">
                        <thead class="text-center">
                            <tr>
                                <th>إسم التطبيق</th>
                                <th>الأيقونة</th>
                                <th>الإجرارات</th>
                            </tr>
                        </thead>
                        <tbody class="text-center">
                            <?php $__empty_1 = true; $__currentLoopData = $apps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $app): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr id="row_<?php echo e($app->id); ?>">
                                <td>
                                    <?php echo e($app['appName_ar']); ?> - <?php echo e($app['appName_en']); ?>

                                </td>
                                <td>
                                    <img class="round border" src="<?php echo e($app->photoLink()); ?>" alt="avatar" width="50px" height="50px">
                                </td>
                                <td>
                                    <a href="javascript:;" data-bs-target="#editapp<?php echo e($app->id); ?>" data-bs-toggle="modal" class="btn btn-icon btn-info" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-original-title="<?php echo e(trans('common.edit')); ?>">
                                        <i data-feather='edit'></i>
                                    </a>
                                    <?php $delete = route('admin.socialMedia.delete',['id'=>$app->id]); ?>
                                    <button type="button" class="btn btn-icon btn-danger" onclick="confirmDelete('<?php echo e($delete); ?>','<?php echo e($app->id); ?>')" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-original-title="<?php echo e(trans('common.delete')); ?>">
                                        <i data-feather='trash-2'></i>
                                    </button>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="5" class="p-3 text-center ">
                                        <h2><?php echo e(trans('common.nothingToView')); ?></h2>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>

                <?php $__currentLoopData = $apps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $app): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="modal fade text-md-start" id="editapp<?php echo e($app->id); ?>" tabindex="-1" aria-hidden="true">
                        <div class="modal-dialog modal-lg modal-dialog-centered modal-edit-user">
                            <div class="modal-content">
                                <div class="modal-header bg-transparent">
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <div class="modal-body pb-5 px-sm-5 pt-50">
                                    <div class="text-center mb-2">
                                        <h1 class="mb-1">تعديل</h1>
                                    </div>
                                    <?php echo e(Form::open(['url'=>route('admin.socialMedia.update',['id'=>$app->id]), 'id'=>'editappForm', 'class'=>'row gy-1 pt-75','files'=>'true'])); ?>

                                        <div class="col-12 col-md-6">
                                            <label class="form-label" for="appName_ar">إسم التطبيق بالعربية</label>
                                            <?php echo e(Form::text('appName_ar',$app->appName_ar,['id'=>'appName_ar', 'class'=>'form-control'])); ?>

                                        </div>
                                        <div class="col-12 col-md-6">
                                            <label class="form-label" for="appName_en">إسم التطبيق بالإنجليزية</label>
                                            <?php echo e(Form::text('appName_en',$app->appName_en,['id'=>'appName_en', 'class'=>'form-control'])); ?>

                                        </div>

                                        <div class="col-12 col-md-12">
                                            <label class="form-label" for="icon">الصورة</label>
                                            <?php echo e(Form::file('icon',['id'=>'icon', 'class'=>'form-control'])); ?>

                                        </div>

                                        <div class="col-12 text-center mt-2 pt-50">
                                            <button type="submit" class="btn btn-primary me-1">حفظ التغييرات</button>
                                            <button type="reset" class="btn btn-outline-secondary" data-bs-dismiss="modal" aria-label="Close">
                                                إلغاء
                                            </button>
                                        </div>
                                    <?php echo e(Form::close()); ?>

                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                <?php echo e($apps->links('vendor.pagination.default')); ?>



            </div>
        </div>
    </div>
    <!-- Bordered table end -->



<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_buttons'); ?>
    <a href="javascript:;" data-bs-target="#createapp" data-bs-toggle="modal" class="btn btn-primary">
        إضافة جديد
    </a>

    <div class="modal fade text-md-start" id="createapp" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered modal-edit-user">
            <div class="modal-content">
                <div class="modal-header bg-transparent">
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body pb-5 px-sm-5 pt-50">
                    <div class="text-center mb-2">
                        <h1 class="mb-1">إضافة جديد</h1>
                    </div>
                    <?php echo e(Form::open(['url'=>route('admin.socialMedia.store'), 'id'=>'createappForm', 'class'=>'row gy-1 pt-75', 'files'=>'true'])); ?>

                        <div class="col-12 col-md-6">
                            <label class="form-label" for="appName_ar">إسم التطبيق بالعربية</label>
                            <?php echo e(Form::text('appName_ar','',['id'=>'appName_ar', 'class'=>'form-control'])); ?>

                        </div>
                        <div class="col-12 col-md-6">
                            <label class="form-label" for="appName_en">إسم التطبيق بالإنجليزية</label>
                            <?php echo e(Form::text('appName_en','',['id'=>'appName_en', 'class'=>'form-control'])); ?>

                        </div>
                        <div class="col-12 col-md-12">
                            <label class="form-label" for="icon">الأيقونة</label>
                            <?php echo e(Form::file('icon',['id'=>'icon', 'class'=>'form-control'])); ?>

                        </div>
                        <div class="col-12 text-center mt-2 pt-50">
                            <button type="submit" class="btn btn-primary me-1">حفظ التغييرات</button>
                            <button type="reset" class="btn btn-outline-secondary" data-bs-dismiss="modal" aria-label="Close">
                                إالغاء
                            </button>
                        </div>
                    <?php echo e(Form::close()); ?>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('AdminPanel.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\switch-app\resources\views/AdminPanel/SocialMedia/index.blade.php ENDPATH**/ ?>