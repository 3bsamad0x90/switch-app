<!-- form -->
<div class="row">
    <div class="col-md-3 text-center">
        <div>
        <h4>لوجـو الموقع</h4>
        </div>
        <?php echo getSettingImageValue('logo'); ?>

        <div class="file-loading">
            <input class="files" name="logo" type="file">
        </div>
    </div>
</div>
<!--/ form -->
<?php /**PATH C:\xampp\htdocs\Laravel\switch-app\resources\views/AdminPanel/settings/includes/images.blade.php ENDPATH**/ ?>