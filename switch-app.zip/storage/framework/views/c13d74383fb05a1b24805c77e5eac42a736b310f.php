<!-- BEGIN: Main Menu-->
<div class="main-menu menu-fixed menu-dark menu-accordion menu-shadow" data-scroll-to-active="true">
    <div class="navbar-header text-center d-flex justify-content-center">
        
            <img src="<?php echo e(asset(getSettingImageLink('logo'))); ?>" width="50%" />
        
    </div>
    <div class="shadow-bottom"></div>
    <div class="main-menu-content">
        <ul class="navigation navigation-main" id="main-menu-navigation" data-menu="menu-navigation">
            <li class="<?php if(isset($active) && $active == 'panelHome'): ?> active <?php endif; ?> nav-item" >
                <a class="d-flex align-items-center" href="<?php echo e(route('admin.index')); ?>">
                    <i data-feather="home"></i>
                    <span class="menu-title text-truncate" data-i18n="<?php echo e(trans('common.PanelHome')); ?>">
                        <?php echo e(trans('common.PanelHome')); ?>

                    </span>
                </a>
            </li>
            <li class="nav-item <?php if(isset($active) && $active == 'setting'): ?> active <?php endif; ?>">
                <a class="d-flex align-items-center" href="<?php echo e(route('admin.settings.general')); ?>">
                    <i data-feather='settings'></i>
                    <span class="menu-title text-truncate" data-i18n="<?php echo e(trans('common.setting')); ?>">
                        الإعدادات
                    </span>
                </a>
            </li>

            <li class="nav-item <?php if(isset($active) && $active == 'products'): ?> active <?php endif; ?>">
                <a class="d-flex align-items-center" href="<?php echo e(route('admin.products')); ?>">
                    <i data-feather='book-open'></i>
                    <span class="menu-title text-truncate" data-i18n="<?php echo e(trans('common.products')); ?>">
                        إدارة المنتجات
                    </span>
                </a>
            </li>
            <li class="nav-item <?php if(isset($active) && $active == 'orders'): ?> active <?php endif; ?>">
                <a class="d-flex align-items-center" href="<?php echo e(route('admin.orders')); ?>">
                    <i data-feather='shopping-cart'></i>
                    <span class="menu-title text-truncate" data-i18n="<?php echo e(trans('common.orders')); ?>">
                        إدارة الطلبات
                    </span>
                </a>
            </li>
            <li class=" nav-item">
                <a class="d-flex align-items-center" href="#">
                    <i data-feather="smile"></i>
                    <span class="menu-title text-truncate" data-i18n="<?php echo e(trans('common.apps')); ?>">
                        التطبيقات
                    </span>
                </a>
                <ul class="menu-content">
                    <li <?php if(isset($active) && $active == 'SocialMedia'): ?> class="active" <?php endif; ?>>
                        <a class="d-flex align-items-center" href="<?php echo e(route('admin.socialMedia')); ?>">
                            <i data-feather="aperture"></i>
                            <span class="menu-item text-truncate" data-i18n="<?php echo e(trans('common.books')); ?>">
                                تطبيقات السوشيال ميديا
                            </span>
                        </a>
                    </li>
                    <li <?php if(isset($active) && $active == 'Music'): ?> class="active" <?php endif; ?>>
                        <a class="d-flex align-items-center" href="<?php echo e(route('admin.Music')); ?>">
                            <i data-feather="headphones"></i>
                            <span class="menu-item text-truncate" data-i18n="<?php echo e(trans('common.Music')); ?>">
                                تطبيقات الأغاني
                            </span>
                        </a>
                    </li>
                    <li <?php if(isset($active) && $active == 'business'): ?> class="active" <?php endif; ?>>
                        <a class="d-flex align-items-center" href="<?php echo e(route('admin.business')); ?>">
                            <i data-feather="briefcase"></i>
                            <span class="menu-item text-truncate" data-i18n="<?php echo e(trans('common.business')); ?>">
                                تطبيقات تجارية
                            </span>
                        </a>
                    </li>
                    <li <?php if(isset($active) && $active == 'creative'): ?> class="active" <?php endif; ?>>
                        <a class="d-flex align-items-center" href="<?php echo e(route('admin.creative')); ?>">
                            <i data-feather="command"></i>
                            <span class="menu-item text-truncate" data-i18n="<?php echo e(trans('common.creative')); ?>">
                                تطبيقات كرييتف
                            </span>
                        </a>
                    </li>
                </ul>
            </li>
            <li class="nav-item <?php if(isset($active) && $active == 'serialNumbers'): ?> active <?php endif; ?>">
                <a class="d-flex align-items-center" href="<?php echo e(route('admin.SerialNumbers')); ?>">
                    <i data-feather='hash'></i>
                    <span class="menu-title text-truncate" data-i18n="<?php echo e(trans('common.serialNumbers')); ?>">
                        الأرقام التسلسلية
                    </span>
                </a>
            </li>

            <li class="nav-item <?php if(isset($active) && $active == 'faqs'): ?> active <?php endif; ?>">
                <a class="d-flex align-items-center" href="<?php echo e(route('admin.faqs')); ?>">
                    <i data-feather='help-circle'></i>
                    <span class="menu-title text-truncate" data-i18n="<?php echo e(trans('common.FAQs')); ?>">
                        الأسئلة الشائعة
                    </span>
                </a>
            </li>
            <li class="nav-item <?php if(isset($active) && $active == 'contactMessages'): ?> active <?php endif; ?>">
                <a class="d-flex align-items-center" href="<?php echo e(route('admin.contactmessages')); ?>">
                    <i data-feather='mail'></i>
                    <span class="menu-title text-truncate" data-i18n="<?php echo e(trans('common.contactMessages')); ?>">
                        <?php echo e(trans('common.contactMessages')); ?>

                    </span>
                </a>
            </li>
        </ul>
    </div>
</div>
<!-- END: Main Menu-->
<?php /**PATH C:\xampp\htdocs\Laravel\switch-app\resources\views/AdminPanel/layouts/AdminMenu.blade.php ENDPATH**/ ?>