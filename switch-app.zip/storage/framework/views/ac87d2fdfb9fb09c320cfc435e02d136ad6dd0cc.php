
<?php $__env->startSection('content'); ?>


    <!-- Bordered table start -->
    <div class="row" id="table-bordered">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title"><?php echo e($title); ?></h4>
                </div>
                <div class="table-responsive">
                    <table class="table table-bordered mb-2">
                        <thead>
                            <tr>
                                <th>السؤال</th>
                                <th class="text-center">الإجراءات</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr id="row_<?php echo e($faq->id); ?>">
                                <td>
                                    <?php echo e($faq['question_ar']); ?><br>
                                    <?php echo e($faq['question_en']); ?>

                                </td>
                                <td class="text-center">
                                    <a href="javascript:;" data-bs-target="#editfaq<?php echo e($faq->id); ?>" data-bs-toggle="modal" class="btn btn-icon btn-info" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-original-title="<?php echo e(trans('common.edit')); ?>">
                                        <i data-feather='edit'></i>
                                    </a>
                                    <?php $delete = route('admin.faqs.delete',['id'=>$faq->id]); ?>
                                    <button type="button" class="btn btn-icon btn-danger" onclick="confirmDelete('<?php echo e($delete); ?>','<?php echo e($faq->id); ?>')" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-original-title="<?php echo e(trans('common.delete')); ?>">
                                        <i data-feather='trash-2'></i>
                                    </button>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="5" class="p-3 text-center ">
                                        <h2><?php echo e(trans('common.nothingToView')); ?></h2>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>

                <?php $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="modal fade text-md-start" id="editfaq<?php echo e($faq->id); ?>" tabindex="-1" aria-hidden="true">
                        <div class="modal-dialog modal-lg modal-dialog-centered modal-edit-user">
                            <div class="modal-content">
                                <div class="modal-header bg-transparent">
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <div class="modal-body pb-5 px-sm-5 pt-50">
                                    <div class="text-center mb-2">
                                        <h1 class="mb-1"><?php echo e(trans('common.edit')); ?></h1>
                                    </div>
                                    <?php echo e(Form::open(['url'=>route('admin.faqs.update',['id'=>$faq->id]), 'id'=>'editfaqForm', 'class'=>'row gy-1 pt-75'])); ?>


                                        <div class="col-12">
                                            <label class="form-label" for="question_ar"><?php echo e(trans('common.question_ar')); ?></label>
                                            <?php echo e(Form::text('question_ar',$faq->question_ar,['id'=>'question_ar', 'class'=>'form-control'])); ?>

                                        </div>
                                        <div class="col-12">
                                            <label class="form-label" for="question_en"><?php echo e(trans('common.question_en')); ?></label>
                                            <?php echo e(Form::text('question_en',$faq->question_en,['id'=>'question_en', 'class'=>'form-control'])); ?>

                                        </div>


                                        <div class="col-12">
                                            <label class="form-label" for="answer_ar"><?php echo e(trans('common.answer_ar')); ?></label>
                                            <?php echo Form::textarea('answer_ar',$faq->answer_ar,['id'=>'answer_ar', 'class'=>'form-control editor_ar']); ?>

                                        </div>
                                        <div class="col-12">
                                            <label class="form-label" for="answer_en"><?php echo e(trans('common.answer_en')); ?></label>
                                            <?php echo Form::textarea('answer_en',$faq->answer_en,['id'=>'answer_en', 'class'=>'form-control editor_en']); ?>

                                        </div>

                                        <div class="col-12 text-center mt-2 pt-50">
                                            <button type="submit" class="btn btn-primary me-1"><?php echo e(trans('common.Save changes')); ?></button>
                                            <button type="reset" class="btn btn-outline-secondary" data-bs-dismiss="modal" aria-label="Close">
                                                <?php echo e(trans('common.Cancel')); ?>

                                            </button>
                                        </div>
                                    <?php echo e(Form::close()); ?>

                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                <?php echo e($faqs->links('vendor.pagination.default')); ?>



            </div>
        </div>
    </div>
    <!-- Bordered table end -->



<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_buttons'); ?>
    <a href="javascript:;" data-bs-target="#createfaq" data-bs-toggle="modal" class="btn btn-primary">
        إضافة جديد
    </a>

    <div class="modal fade text-md-start" id="createfaq" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered modal-edit-user">
            <div class="modal-content">
                <div class="modal-header bg-transparent">
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body pb-5 px-sm-5 pt-50">
                    <div class="text-center mb-2">
                        <h1 class="mb-1"><?php echo e(trans('common.CreateNew')); ?></h1>
                    </div>
                    <?php echo e(Form::open(['url'=>route('admin.faqs.store'), 'id'=>'createfaqForm', 'class'=>'row gy-1 pt-75'])); ?>


                        <div class="col-12 col-md-12">
                            <label class="form-label" for="question_ar">السؤال بالعربية</label>
                            <?php echo e(Form::text('question_ar','',['id'=>'question_ar', 'class'=>'form-control'])); ?>

                        </div>
                        <div class="col-12 col-md-12">
                            <label class="form-label" for="question_en">السؤال بالإنجليزية</label>
                            <?php echo e(Form::text('question_en','',['id'=>'question_en', 'class'=>'form-control'])); ?>

                        </div>


                        <div class="col-12 col-md-12">
                            <label class="form-label" for="answer_ar"><?php echo e(trans('common.answer_ar')); ?></label>
                            <?php echo e(Form::textarea('answer_ar','',['id'=>'answer_ar', 'class'=>'form-control editor_ar'])); ?>

                        </div>
                        <div class="col-12 col-md-12">
                            <label class="form-label" for="answer_en"><?php echo e(trans('common.answer_en')); ?></label>
                            <?php echo e(Form::textarea('answer_en','',['id'=>'answer_en', 'class'=>'form-control editor_en'])); ?>

                        </div>

                        <div class="col-12 text-center mt-2 pt-50">
                            <button type="submit" class="btn btn-primary me-1"><?php echo e(trans('common.Save changes')); ?></button>
                            <button type="reset" class="btn btn-outline-secondary" data-bs-dismiss="modal" aria-label="Close">
                                <?php echo e(trans('common.Cancel')); ?>

                            </button>
                        </div>
                    <?php echo e(Form::close()); ?>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('AdminPanel.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\switch-app\resources\views/AdminPanel/FAQs/index.blade.php ENDPATH**/ ?>