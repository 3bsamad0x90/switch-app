<?php $__env->startSection('content'); ?>


    <!-- Bordered table start -->
    <div class="row" id="table-bordered">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">بيانات المستخدم</h4>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-2">
                            <b>الإسم:</b>
                            <?php echo e($message->userData()['name']); ?>

                        </div>

                        <div class="col-4">
                            <b>الإيميل:</b>
                            <?php echo e($message->userData()['email']); ?>

                        </div>
                        <div class="col-4">
                            <b>الهاتف:</b>
                            <span dir="ltr">
                                <?php echo e($message->userData()['phone']); ?>

                            </span>
                        </div>
                    </div>

                </div>

            </div>
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">تفاصيل الرسالة <small>(<b class="text-danger"><?php echo e($message->subjectText()); ?></b>)</small></h4>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-12">
                            <?php echo e($message->content); ?>

                        </div>
                    </div>

                </div>

            </div>
        </div>
    </div>
    <!-- Bordered table end -->



<?php $__env->stopSection(); ?>

<?php echo $__env->make('AdminPanel.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\switch-app\resources\views/AdminPanel/contactMessages/details.blade.php ENDPATH**/ ?>