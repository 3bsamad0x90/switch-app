
<?php $__env->startSection('content'); ?>


    <!-- Bordered table start -->
    <?php $__errorArgs = ['serial_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <strong><?php echo e($message); ?></strong>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <div class="row" id="table-bordered">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title"><?php echo e($title); ?></h4>
                </div>
                <div class="table-responsive">
                    <table class="table table-bordered mb-2">
                        <thead class="text-center">
                            <tr>
                                <th>الرقم</th>
                                <th>الإجراءات</th>
                            </tr>
                        </thead>
                        <tbody class="text-center">
                            <?php $__empty_1 = true; $__currentLoopData = $SerialNumbers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $SerialNumber): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr id="row_<?php echo e($SerialNumber->id); ?>">
                                <td>
                                    <?php echo e($SerialNumber['serial_number']); ?>

                                </td>
                                <td class="text-center">
                                    <a href="javascript:;" data-bs-target="#editSerialNumber<?php echo e($SerialNumber->id); ?>" data-bs-toggle="modal" class="btn btn-icon btn-info" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-original-title="<?php echo e(trans('common.edit')); ?>">
                                        <i data-feather='edit'></i>
                                    </a>
                                    <?php $delete = route('admin.SerialNumbers.delete',['id'=>$SerialNumber->id]); ?>
                                    <button type="button" class="btn btn-icon btn-danger" onclick="confirmDelete('<?php echo e($delete); ?>','<?php echo e($SerialNumber->id); ?>')" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-original-title="<?php echo e(trans('common.delete')); ?>">
                                        <i data-feather='trash-2'></i>
                                    </button>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="5" class="p-3 text-center ">
                                        <h2>لا يوجد أي بيانات لعرضها الآن</h2>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>

                <?php $__currentLoopData = $SerialNumbers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $SerialNumber): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="modal fade text-md-start" id="editSerialNumber<?php echo e($SerialNumber->id); ?>" tabindex="-1" aria-hidden="true">
                        <div class="modal-dialog modal-lg modal-dialog-centered modal-edit-user">
                            <div class="modal-content">
                                <div class="modal-header bg-transparent">
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <div class="modal-body pb-5 px-sm-5 pt-50">
                                    <div class="text-center mb-2">
                                        <h1 class="mb-1"><?php echo e(trans('common.edit')); ?></h1>
                                    </div>
                                    <?php echo e(Form::open(['url'=>route('admin.SerialNumbers.update',['id'=>$SerialNumber->id]), 'id'=>'editSerialNumberForm', 'class'=>'row gy-1 pt-75'])); ?>

                                        <div class="col-12 col-md-12">
                                            <label class="form-label" for="serial_number">الرقم التسلسلي</label>
                                            <?php echo e(Form::text('serial_number',$SerialNumber->serial_number,['id'=>'serial_number', 'class'=>'form-control'])); ?>

                                        </div>
                                    
                                        <div class="col-12 text-center mt-2 pt-50">
                                            <button type="submit" class="btn btn-primary me-1"><?php echo e(trans('common.Save changes')); ?></button>
                                            <button type="reset" class="btn btn-outline-secondary" data-bs-dismiss="modal" aria-label="Close">
                                                <?php echo e(trans('common.Cancel')); ?>

                                            </button>
                                        </div>
                                    <?php echo e(Form::close()); ?>

                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                


            </div>
        </div>
    </div>
    <!-- Bordered table end -->



<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_buttons'); ?>
    <a href="javascript:;" data-bs-target="#createSerialNumber" data-bs-toggle="modal" class="btn btn-primary">
        <?php echo e(trans('common.CreateNew')); ?>

    </a>

    <div class="modal fade text-md-start" id="createSerialNumber" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered modal-edit-user">
            <div class="modal-content">
                <div class="modal-header bg-transparent">
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body pb-5 px-sm-5 pt-50">
                    <div class="text-center mb-2">
                        <h1 class="mb-1"><?php echo e(trans('common.CreateNew')); ?></h1>
                    </div>
                    <?php echo e(Form::open(['url'=>route('admin.SerialNumbers.store'), 'id'=>'createSerialNumberForm', 'class'=>'row gy-1 pt-75'])); ?>

                        <div class="col-12 col-md-12">
                            <label class="form-label" for="serial_number">الرقم التسلسلي</label>
                            <?php echo e(Form::text('serial_number','',['id'=>'serial_number', 'class'=>'form-control'])); ?>

                        </div>
                        <div class="col-12 text-center mt-2 pt-50">
                            <button type="submit" class="btn btn-primary me-1">حفظ التغييرات</button>
                            <button type="reset" class="btn btn-outline-secondary" data-bs-dismiss="modal" aria-label="Close">
                                إالغاء
                            </button>
                        </div>
                    <?php echo e(Form::close()); ?>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('AdminPanel.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\switch-app\resources\views/AdminPanel/SerialNumbers/index.blade.php ENDPATH**/ ?>