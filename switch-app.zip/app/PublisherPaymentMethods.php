<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PublisherPaymentMethods extends Model
{
    //
    protected $guarded = [];
}
